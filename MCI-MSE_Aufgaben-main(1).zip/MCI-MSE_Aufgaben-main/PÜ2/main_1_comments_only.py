# UC 2.0

#%% UC 2.1 Einlesen der Daten

