# Leistungsdiagnostik
**(kurze Beschreibung des Ziels)**

Werkzeug zur Vereinfachung und Automatisierung von Leistungstests, basierend auf EKG-Daten und Leistungswerten und Patient:innen-Daten

## Installation

(Was muss man tun, bevor man das Werkzeug nutzen kann?)

t.b.d.

## Usage

(Wie benutzt man das Werkzeug. Wo müssen Daten in welcher Form liegen?)

Start über Kommandozeile
```python main.py```

Daten müssen wie wie folgt vorliegen?

## Contributing
**(Wer ist im Team Name + Matrikelnummer + Email)**

- [Julian Huber - 123](julian.huber@mci.edu)

## License
[MIT](https://choosealicense.com/licenses/mit/)