## Project background

### Purpose of project

...

### Scope of project

...

### Other background information

...

## Perspectives
### Who will use the system?

...

### Who can provide input about the system?

...


## Project Objectives
### Known business rules

...

### System information and/or diagrams

Beispiel von aufgezeichneten EKG Daten
![](ekg_example.png)

Aus diesem muss die Herzrate bestimmt werden.

### Assumptions and dependencies

...

### Design and implementation constraints

...

## Risks

...

## Known future enhancements

...

## References

- [Link zur Aufgabenstellung](tbd)

## Open, unresolved or TBD issues

...